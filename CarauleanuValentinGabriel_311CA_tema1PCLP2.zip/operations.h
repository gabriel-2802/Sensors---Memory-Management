//copyright Carauleanu Valentin Gabriel 311CAb
#pragma once
#include "structs.h"
#include <stdio.h>

void get_operations(void **operations);