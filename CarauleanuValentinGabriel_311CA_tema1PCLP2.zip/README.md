//copyright Carauleanu Valentin Gabriel 311CAb

Programul final utilizeaza urmatoarele 3 biblioteci statice: 

	-> commands.h : formata din functiile principale ale
                programului: read, print, clear, sort, analyze si
                free

	-> aux_functions.h : formata din functii
                        auxiliare celor din commands.h

	-> operations.h : formata din functia get_operations
